#!/usr/bin/env python
# vim: set fileencoding=utf-8 ts=4 sts=4 sw=4 et tw=80 :
#
# Plot NRES RV results (distilled from PDF + table) for analysis.
#
# Rob Siverd
# Created:       2018-03-25
# Last modified: 2018-03-26
#--------------------------------------------------------------------------
#**************************************************************************
#--------------------------------------------------------------------------

## Current version:
__version__ = "0.1.0"

## Optional matplotlib control:
#from matplotlib import use, rc, rcParams
#from matplotlib import use
#from matplotlib import rc
#from matplotlib import rcParams
#use('GTKAgg')  # use GTK with Anti-Grain Geometry engine
#use('agg')     # use Anti-Grain Geometry engine (file only)
#use('ps')      # use PostScript engine for graphics (file only)
#use('cairo')   # use Cairo (pretty, file only)
#rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
#rc('font',**{'family':'serif','serif':['Palatino']})
#rc('font',**{'sans-serif':'Arial','family':'sans-serif'})
#rc('text', usetex=True) # enables text rendering with LaTeX (slow!)
#rcParams['axes.formatter.useoffset'] = False   # v. 1.4 and later

## Python version-agnostic module reloading:
try:
    reload                              # Python 2.7
except NameError:
    try:
        from importlib import reload    # Python 3.4+
    except ImportError:
        from imp import reload          # Python 3.0 - 3.3

## Modules:
#import argparse
#import mimetypes
#import linecache
import getopt
#import shutil
import resource
import signal
#import glob
import gc
import os
import sys
import time
#import ephem
import numpy as np
#import datetime as dt
#import scipy.linalg as sla
#import scipy.signal as ssig
#import scipy.ndimage as ndi
#import scipy.optimize as opti
#import scipy.interpolate as stp
#import scipy.spatial.distance as ssd
import matplotlib.pyplot as plt
#import matplotlib.cm as cm
#import matplotlib.ticker as mt
#import matplotlib._pylab_helpers as hlp
#from matplotlib.colors import LogNorm
#from matplotlib import colors
#import matplotlib.colors as mplcolors
import matplotlib.gridspec as gridspec
from functools import partial
#from collections import OrderedDict
#import multiprocessing as mp
#np.set_printoptions(suppress=True, linewidth=160)
#import pandas as pd
#import statsmodels.api as sm
#import statsmodels.formula.api as smf
#from statsmodels.regression.quantile_regression import QuantReg
#import PIL.Image as pli
#import seaborn as sns
import theil_sen as ts
#import window_filter as wf
#import itertools as itt

import lc
reload(lc)
kk = lc.LC()
kk.closeLCwin()
kk.lcwN = 5

import orbit
reload(orbit)

import qfit_orbit
reload(qfit_orbit)
qfo = qfit_orbit.OrbFit()

##--------------------------------------------------------------------------##

## Home-brew KDE:
#try:
#    import my_kde
#    reload(my_kde)
#    mk = my_kde
#except ImportError:
#    sys.stderr.write("\nError!  my_kde module not found!\n"
#           "Please install and try again ...\n\n")
#    sys.exit(1)

## Fast FITS I/O:
#try:
#    import fitsio
#except ImportError:
#    sys.stderr.write("\nError: fitsio module not found!\n")
#    sys.exit(1)

## FITS I/O:
#try:
#    import astropy.io.fits as pf
#except ImportError:
#    try:
#       import pyfits as pf
#    except ImportError:
#        sys.stderr.write("\nError!  No FITS I/O module found!\n"
#               "Install either astropy.io.fits or pyfits and try again!\n\n")
#        sys.exit(1)

## ASCII I/O:
#try:
#    import astropy.io.ascii as aia
#except ImportError:
#    sys.stderr.write("\nError: astropy module not found!\n")
#    sys.exit(1)

## Time conversion:
#try:
#    import astropy.time as astt
#except ImportError:
#    sys.stderr.write("\nError: astropy module not found!\n"
#           "Please install and try again.\n\n")
#    sys.exit(1)

##--------------------------------------------------------------------------##
## Colors for fancy terminal output:
NRED    = '\033[0;31m'   ;  BRED    = '\033[1;31m'
NGREEN  = '\033[0;32m'   ;  BGREEN  = '\033[1;32m'
NYELLOW = '\033[0;33m'   ;  BYELLOW = '\033[1;33m'
NBLUE   = '\033[0;34m'   ;  BBLUE   = '\033[1;34m'
NMAG    = '\033[0;35m'   ;  BMAG    = '\033[1;35m'
NCYAN   = '\033[0;36m'   ;  BCYAN   = '\033[1;36m'
NWHITE  = '\033[0;37m'   ;  BWHITE  = '\033[1;37m'
ENDC    = '\033[0m'

## Suppress colors in cron jobs:
if (os.getenv('FUNCDEF') == '--nocolors'):
    NRED    = ''   ;  BRED    = ''
    NGREEN  = ''   ;  BGREEN  = ''
    NYELLOW = ''   ;  BYELLOW = ''
    NBLUE   = ''   ;  BBLUE   = ''
    NMAG    = ''   ;  BMAG    = ''
    NCYAN   = ''   ;  BCYAN   = ''
    NWHITE  = ''   ;  BWHITE  = ''
    ENDC    = ''

## Fancy text:
degree_sign = u'\N{DEGREE SIGN}'

## Dividers:
halfdiv = "----------------------------------------"
fulldiv = halfdiv + halfdiv

##--------------------------------------------------------------------------##
## Catch interruption cleanly:
def signal_handler(signum, frame):
    sys.stderr.write("\nInterrupted!\n\n")
    sys.exit(1)

signal.signal(signal.SIGINT, signal_handler)

##--------------------------------------------------------------------------##
## Save FITS image with clobber (astropy / pyfits):
#def qsave(iname, idata, header=None, padkeys=1000, **kwargs):
#    this_func = sys._getframe().f_code.co_name
#    sys.stderr.write("Writing to '%s' ... " % iname)
#    if header:
#        while (len(header) < padkeys):
#            header.append() # pad header
#    if os.path.isfile(iname):
#        os.remove(iname)
#    pf.writeto(iname, idata, header=header, **kwargs)
#    sys.stderr.write("done.\n")

##--------------------------------------------------------------------------##
## Save FITS image with clobber (fitsio):
#def qsave(iname, idata, header=None, **kwargs):
#    this_func = sys._getframe().f_code.co_name
#    sys.stderr.write("Writing to '%s' ... " % iname)
#    #if os.path.isfile(iname):
#    #    os.remove(iname)
#    fitsio.write(iname, idata, clobber=True, header=header, **kwargs)
#    sys.stderr.write("done.\n")

##--------------------------------------------------------------------------##
def argnear(vec, val):
    return (np.abs(vec - val)).argmin()

## Robust location/scale estimate using median/MAD:
def calc_ls_med_MAD(a, axis=None):
    """Return median and median absolute deviation of *a* (scaled to normal)."""
    med_val = np.median(a, axis=axis)
    sig_hat = (1.482602218 * np.median(np.abs(a - med_val), axis=axis))
    return (med_val, sig_hat)

## Robust location/scale estimate using median/IQR:
def calc_ls_med_IQR(a, axis=None):
    """Return median and inter-quartile range of *a* (scaled to normal)."""
    pctiles = np.percentile(a, [25, 50, 75], axis=axis)
    med_val = pctiles[1]
    sig_hat = (0.741301109 * (pctiles[2] - pctiles[0]))
    return (med_val, sig_hat)

## Select inliners given specified sigma threshold:
def pick_inliers(data, sig_thresh):
    med, sig = calc_ls_med_IQR(data)
    return ((np.abs(data - med) / sig) <= sig_thresh)

## Settings:
debug = False
timer = False
vlevel = 0
prog_name = 'quickplot_rvs.py'
full_prog = sys.argv[0]
base_prog = os.path.basename(full_prog)
num_todo = 0

## Options:
save_file = None
ephem_file = None
orbital_period = None

##--------------------------------------------------------------------------##
## Argument type-checking:
def is_integer(asdf):
    try:
        int(asdf)
        return True
    except ValueError:
        return False

def is_float(asdf):
    try:
        float(asdf)
        return True
    except ValueError:
        return False

def parse_limit_string(lstring, ordered=True):
    """Returns lower,upper,valid tuple."""
    pieces = lstring.split(',')

    # Limit string must contain two elements:
    if len(pieces) != 2:
        return (None, None, False)      # exactly two elements required

    # Limits must be numbers:
    if not all([is_float(x) for x in pieces]):
        return (None, None, False)      # limits must be numbers

    # Extract:
    lower, upper = [float(x) for x in pieces]
    if ordered:
        lower, upper = (lower, upper) if (lower < upper) else (upper, lower)
    return lower, upper, True

##--------------------------------------------------------------------------##
##*********************     Help and options menu:     *********************##
##--------------------------------------------------------------------------##

## Syntax / how to run:
def usage(stream):
    stream.write("\n"
        + "Usage: %s [options] NRES_RV_data.txt\n" % base_prog
        + "Plot NRES RV results for inspection.\n"
        + "Version: %s\n" % __version__
        + "\n"
        + "Target information:\n"
        + "   -E, --ephems=FILE    data file with target ephemerides\n"
        + "   -P, --period=DAYS    target orbital period [days]\n"
        + "\n"
        + "Available options:\n"
        + "       --debug          extra debugging info\n"
        + "   -h, --help           print this page\n"
        + "   -o, --output=FILE    save results to FILE\n"
        + "   -q, --quiet          suppress unnecessary output\n"
        + "   -t, --timer          report program run-time\n"
        + "   -v, --verbose        more status updates\n"
        + "\n")
        #+ "   -n, --numtodo=N     stop after N iterations\n"
        #+ "   -s, --sigcut=N      clip data beyond N*sigma\n"

##--------------------------------------------------------------------------##
##*********************       Parse command line:      *********************##
##--------------------------------------------------------------------------##

## Options:
short_opts = 'E::o:hqtv' # n:s:
long_opts = ['ephems=', 'period=', 'output=',
                'debug', 'help', 'quiet', 'timer', 'verbose']
# 'numtodo=', 'sigcut='

## GNU-style parsing (with exception handling):
try:
    options, remainder = getopt.gnu_getopt(sys.argv[1:], short_opts, long_opts)
except getopt.GetoptError, err:
    sys.stderr.write("%s\n" % str(err))
    usage(sys.stderr)
    sys.exit(2)

## Handle selected options:
for opt, arg in options:
    # ------------------------------------------------
    if (opt == '--debug'):
        debug = True
        sys.stderr.write(BRED + "\nDebugging output enabled!" + ENDC + "\n")
    # ------------------------------------------------
    # ------------------------------------------------
    elif ((opt == '-E') or (opt == '--ephems')):
        if not os.path.isfile(arg):
            sys.stderr.write("File not found: %s\n" % arg)
            sys.exit(1)
        ephem_file = arg
        if (vlevel >= 0):
            msg = "Loading ephemerides from: " + arg
            sys.stderr.write(NYELLOW + msg + ENDC + "\n")
    # ------------------------------------------------
    elif ((opt == '-P') or (opt == '--period')):
        if not is_float(arg):
            sys.stderr.write("Error!  Non-numeric orbit period: %s\n\n" % arg)
            sys.exit(1)
        orbital_period = float(arg)
        if (orbital_period <= 0):
            sys.stderr.write("Error: orbital period must be positive!\n")
            sys.exit(1)
        if (vlevel >= 0):
            msg = "Target orbital period: %.5f days" % orbital_period
            sys.stderr.write(NYELLOW + msg + ENDC + "\n")
    # ------------------------------------------------
    #elif ((opt == '-n') or (opt == '--numtodo')):
    #    if not is_integer(arg):
    #        sys.stderr.write("Error!  Non-integer argument: %s\n\n" % arg)
    #        sys.exit(1)
    #    num_todo = int(arg)
    #    if (vlevel >= 0):
    #        msg = "Stopping after %d items." % num_todo
    #        sys.stderr.write(NYELLOW + msg + ENDC + "\n")
    # ------------------------------------------------
    elif ((opt == '-o') or (opt == '--output')):
        save_file = arg
        if (vlevel >= 0):
            msg = "Saving results to: " + arg
            sys.stderr.write(NYELLOW + msg + ENDC + "\n")
    # ------------------------------------------------
    #elif ((opt == '-s') or (opt == '--sigcut')):
    #    if not is_float(arg):
    #        sys.stderr.write("Error!  Non-numeric argument: %s\n\n" % arg)
    #        sys.exit(1)
    #    sigcut = float(arg)
    #    if (vlevel >= 0):
    #        msg = "Using %.2f-sigma outlier threshold." % sigcut
    #        sys.stderr.write(NYELLOW + msg + ENDC + "\n")
    # ------------------------------------------------
    elif ((opt == '-h') or (opt == '--help')):
        usage(sys.stdout)
        sys.exit(0)
    elif ((opt == '-q') or (opt == '--quiet')):
        vlevel -= 1
    elif ((opt == '-t') or (opt == '--timer')):
        timer = True
    elif ((opt == '-v') | (opt == '--verbose')):
        vlevel += 1
        sys.stderr.write(NYELLOW + "Increasing verbosity." + ENDC + "\n")
    # ------------------------------------------------
    else:
        msg = "Unhandled option: %s" % opt
        sys.stderr.write(BRED + "\n" + msg + ENDC + "\n\n")
        sys.exit(1)
    pass

## Verbosity:
if (vlevel >= 1):
    sys.stderr.write("%sVerbosity level: %d%s\n" % (NYELLOW, vlevel, ENDC))

## Full command line if highly verbose:
if (vlevel >= 2):
    sys.stderr.write("%s\nFull command line:%s\n" % (NCYAN, ENDC))
    sys.stderr.write("   %s\n" % sys.argv)

##--------------------------------------------------------------------------##
## Requirements check:
#requirements = [(bias_file, 'bias image'), (imlist_file, 'image list'),
#                (save_file, 'output file'), (fiber_pos[0], 'fiber X position'),
#                (fiber_pos[1], 'fiber Y position'),]
#for var,info in requirements:
#    if var == None:
#        sys.stderr.write(BRED + "No %s provided!" % info + ENDC + "\n")
#        usage(sys.stderr)
#        sys.exit(1)

## Output file is required:
if not save_file:
    sys.stderr.write(BRED + "\nOutput file required!" + ENDC + "\n")
    usage(sys.stderr)
    sys.exit(1)

## Input file is required:
if (len(remainder) < 1):
    sys.stderr.write(BRED + "\nInput file required!" + ENDC + "\n")
    usage(sys.stderr)
    sys.exit(1)

## Check for input file:
data_file = remainder[0]
if not os.path.isfile(data_file):
    msg = "%s error:  file not found: %s" % (prog_name, data_file)
    sys.stderr.write("\n" + BRED + msg + ENDC + "\n")
    sys.exit(1)

##--------------------------------------------------------------------------##
##--------------------------------------------------------------------------##
##--------------------------------------------------------------------------##

## Quick ASCII I/O:
#data_file = 'data.txt'
#all_data = np.genfromtxt(data_file, dtype=None)
all_data = np.genfromtxt(data_file, dtype=None, names=True, autostrip=True)
#all_data = np.genfromtxt(data_file, dtype=None, names=True, autostrip=True,
#                 delimiter='|', comments='%0%0%0%0')
#                 loose=True, invalid_raise=False)
#all_data = aia.read(data_file)
#all_data = pd.read_csv(data_file)
#all_data = pd.read_table(data_file, delim_whitespace=True)
#all_data = pd.read_table(data_file, sep='|')
fields = all_data.dtype.names
n_raw_data = len(all_data)

## Ignore data with low SNR:
#snr_cut = 10.0
#keepers = (all_data['snr'] >= snr_cut)
#all_data = all_data[keepers]

## Toss extreme outliers:
keepers = pick_inliers(all_data['ccval'], 10)
all_data = all_data[keepers]
n_use_data = len(all_data)
sys.stderr.write("Kept %d of %d data points.\n" % (n_use_data, n_raw_data))

## Actionable quantities:
#use_tvec = timestamp - jd_offset
timestamp = all_data['bjd_obs']
jd_offset = timestamp.min()         # note for plotting
rad_vel   = all_data['ccval']

## Parse LCO site:
lco_site = np.array([x[:3] for x in all_data['tarball']])

##--------------------------------------------------------------------------##
## Load ephemerides and look for match if file provided:
eph_data = []
targ_period = None
targ_eclmid = None
_have_ephem = False
orbit_phase = None
my_targname = None
if isinstance(ephem_file, str):
    eph_data = np.genfromtxt(ephem_file, dtype=None, 
            names=True, autostrip=True)
else:
    sys.stderr.write("No ephemeris file provided.\n")

## Look for matching ephemeris:
if (len(eph_data) > 0):
    for targname in all_data['target']:
        hits = (targname == eph_data['target'])
        if (np.sum(hits) == 1):
            eph_match = eph_data[hits]
            sys.stderr.write("Found ephemeris: %s\n" % str(eph_match))
            targ_period = eph_match['period'][0]
            targ_eclmid = eph_match['mid_eclipse'][0]
            my_targname = targname
            _have_ephem = True
            break
        pass
    pass

##--------------------------------------------------------------------------##
## Compute orbital phase:
if _have_ephem:
    orbit_cycle = (timestamp - targ_eclmid) / targ_period
    orbit_phase = orbit_cycle % 1.0

##--------------------------------------------------------------------------##
## Timestamp modification:
def time_warp(jdutc, jd_offset, scale):
    return (jdutc - jd_offset) * scale

## Self-consistent time-modification for plotting:
tfudge = partial(time_warp, jd_offset=jd_offset, scale=1.0)    # relative days
#tfudge = partial(time_warp, jd_offset=tstart.jd, scale=24.0)    # relative hrs
#tfudge = partial(time_warp, jd_offset=tstart.jd, scale=1440.0)  # relative min

##--------------------------------------------------------------------------##
## Misc:
#def log_10_product(x, pos):
#   """The two args are the value and tick position.
#   Label ticks with the product of the exponentiation."""
#   return '%.2f' % (x)  # floating-point
#
#formatter = plt.FuncFormatter(log_10_product) # wrap function for use

## Convenient, percentile-based plot limits:
#def nice_limits(vec, pctiles=[1,99], pad=1.2):
#    ends = np.percentile(vec, pctiles)
#    middle = np.average(ends)
#    return (middle + pad * (ends - middle))

## Convenient plot limits for datetime/astropy.Time content:
#def nice_time_limits(tvec, buffer=0.05):
#    lower = tvec.min()
#    upper = tvec.max()
#    ndays = upper - lower
#    return ((lower - 0.05*ndays).datetime, (upper + 0.05*ndays).datetime)

## Convenient limits for datetime objects:
#def dt_limits(vec, pad=0.1):
#    tstart, tstop = vec.min(), vec.max()
#    trange = (tstop - tstart).total_seconds()
#    tpad = dt.timedelta(seconds=pad*trange)
#    return (tstart - tpad, tstop + tpad)

##--------------------------------------------------------------------------##
## Theil-Sen line-fitting for linear trend removal:
#icept, slope = ts.linefit(timestamp, rad_vel)
trend = ts.linefit(timestamp, rad_vel)
sys.stderr.write("Got linear fit of %10.5f km/s/day\n" % trend[1])
detrend_RV = rad_vel - (trend[0] + timestamp * trend[1])

##--------------------------------------------------------------------------##
##------------------           Basic RV Analysis            ----------------##
##--------------------------------------------------------------------------##

if _have_ephem:
    qfo.set_data(timestamp, rad_vel)
    qfo.set_element('per', targ_period) # known orbital period
    qfo.set_element('Tp', targ_eclmid)  # guess Tperi ~= Tc
    #qfo.set_element('Tp', targ_eclmid-1.0)
    #qfo.set_element('Tp', targ_eclmid + 0.5*targ_period)  # guess Tperi ~= Tc
    qfo.set_element('ecc', 0.01)

    if (my_targname == 'KEBC09C05946'):
        qfo.set_element('ecc', 0.5)
        qfo.set_element('w', 4.10)
        pshift = 0.55
        pshift = 0.0

#omegas = 2.0 * np.pi * np.linspace(0.0, 1.0, 10, endpoint=False, dtype='float')
#eccval = 0.8
#for ww in omegas:
#    phi, vel = orbit.orbit_curve(eccval, ww, norm=True)
#    #rvmin, rvmax = curve.min(), curve.max()
#    sys.stderr.write("For ww=%5.3f, RV min/max = %8.4f, %8.4f\n"
#            % (ww, vel.min(), vel.max()))


##--------------------------------------------------------------------------##
## Plot config:

# gridspec examples:
# https://matplotlib.org/users/gridspec.html

#gs1 = gridspec.GridSpec(4, 4)
gs1 = gridspec.GridSpec(2, 2)
#gs1.update(wspace=0.025, hspace=0.05)  # set axis spacing

##--------------------------------------------------------------------------##
fig_dims = (12, 10)
fig = plt.figure(1, figsize=fig_dims)
plt.gcf().clf()
#fig, axs = plt.subplots(2, 2, sharex=True, figsize=fig_dims, num=1)
# sharex='col' | sharex='row'
#fig.frameon = False # disable figure frame drawing
#fig.subplots_adjust(left=0.07, right=0.95)
#ax1 = fig.add_subplot(211)
ax1 = plt.subplot(gs1[0, 0])
#ax1 = fig.add_axes([0, 0, 1, 1])
#ax1.patch.set_facecolor((0.8, 0.8, 0.8))
ax1.grid(True)
#ax1.set_xlabel
ax1.scatter(tfudge(timestamp), rad_vel, lw=0, s=25)
ax1.set_xlabel("Days since %.3f" % jd_offset)
ax1.set_ylabel("Raw RV (km/s)")

#ax1.axis('off')
#ax2 = fig.add_subplot(212) ax2 = plt.subplot(gs1[1, 0])
ax2 = plt.subplot(gs1[1, 0])
ax2.grid(True)
ax2.scatter(tfudge(timestamp), detrend_RV, lw=0, s=25)
ax2.set_xlabel("Days since %.3f" % jd_offset)
ax2.set_ylabel("Detrended RV (km/s)")

if _have_ephem:
    ax3 = plt.subplot(gs1[0, 1])
    ax3.grid(True)
    ax3.scatter(orbit_phase, rad_vel, lw=0, s=25)
    ax3.set_xlim(-0.05, 1.05)
    ax3.set_xlabel("Orbital Phase (P=%.5f days)" % targ_period)
    ax3.set_ylabel("Raw RV (km/s)")
    tphase, tcurve = qfo.make_orbit(points=1000, norm=True)
    tphase = (tphase + pshift) % 1.0
    ax3.scatter(tphase, tcurve, lw=0, s=1, c='r')
    #ax3.plot(tphase, tcurve, lw=1, ls=':', c='r')

if _have_ephem:
    ax4 = plt.subplot(gs1[1, 1])
    ax4.grid(True)
    ax4.scatter(orbit_phase, detrend_RV, lw=0, s=25)
    ax4.set_xlim(-0.05, 1.05)
    ax4.set_xlabel("Orbital Phase (P=%.5f days)" % targ_period)
    ax4.set_ylabel("Detrended RV (km/s)")

## Disable axis offsets:
#ax1.xaxis.get_major_formatter().set_useOffset(False)
#ax1.yaxis.get_major_formatter().set_useOffset(False)

#ax1.plot(kde_pnts, kde_vals)

#blurb = "some text"
#ax1.text(0.5, 0.5, blurb, transform=ax1.transAxes)
#ax1.text(0.5, 0.5, blurb, transform=ax1.transAxes,
#      va='top', ha='left', bbox=dict(facecolor='white', pad=10.0))

#colors = cm.rainbow(np.linspace(0, 1, len(plot_list)))
#for camid, c in zip(plot_list, colors):
#    cam_data = subsets[camid]
#    xvalue = cam_data['CCDATEMP']
#    yvalue = cam_data['PIX_MED']
#    yvalue = cam_data['IMEAN']
#    ax1.scatter(xvalue, yvalue, color=c, lw=0, label=camid)

#mtickpos = [2,5,7]
#ndecades = 1.0   # for symlog, set width of linear portion in units of dex
#nonposx='mask' | nonposx='clip' | nonposy='mask' | nonposy='clip'
#ax1.set_xscale('log', basex=10, nonposx='mask', subsx=mtickpos)
#ax1.set_xscale('log', nonposx='clip', subsx=[3])
#ax1.set_yscale('symlog', basey=10, linthreshy=0.1, linscaley=ndecades)
#ax1.xaxis.set_major_formatter(formatter) # re-format x ticks
#ax1.set_ylim(ax1.get_ylim()[::-1])
#ax1.set_xlabel('whatever', labelpad=30)  # push X label down 

#ax1.set_xticks([1.0, 3.0, 10.0, 30.0, 100.0])
#ax1.set_xticks([1, 2, 3], ['Jan', 'Feb', 'Mar'])
#for label in ax1.get_xticklabels():
#    label.set_rotation(30)

#ax1.set_xlim(nice_limits(xvec, pctiles=[1,99], pad=1.2))
#ax1.set_ylim(nice_limits(yvec, pctiles=[1,99], pad=1.2))

#spts = ax1.scatter(x, y, lw=0, s=5)
#cbar = fig.colorbar(spts, orientation='vertical')
#cbar.formatter.set_useOffset(False)
#cbar.update_ticks()

fig.tight_layout() # adjust boundaries sensibly, matplotlib v1.1+
plt.draw()






#sys.stderr.write("one_vel: %10.5f\n" % one_vel)
#ax3.axhline(one_vel, c='b', lw=0.5)

#def dumb_intersects(mod_phi, mod_vel, phi_data, rv_data):
#    results = []
#    for i, (phase, rad_vel) in enumerate(zip(phi_data, rv_data)):
#        #sys.stderr.write("---------------------------------\n")
#        #sys.stderr.write("Data point %d ... " % i)
#        isect = [round(phase, 5), round(rad_vel, 5)]
#        for ix1 in range(len(mod_phi)):
#            ix2 = (ix1 + 1) % len(mod_phi)
#            #sys.stderr.write("... ix1,ix2 = %d,%d\n" % (ix1,ix2))
#            v1, v2 = mod_vel[ix1], mod_vel[ix2]
#            if ((v1 <= one_vel < v2) if (v2 >= v1) else (v1 > one_vel >= v2)):
#                phi_step = (mod_phi[ix2] - mod_phi[ix1]) % 1.0
#                vel_step = (mod_vel[ix2] - mod_vel[ix1])
#                stepfrac = (rad_vel - mod_vel[ix1]) / vel_step
#                newphase = (mod_phi[ix1] + stepfrac * phi_step) % 1.0
#                #sys.stderr.write("newphase: %10.5f\n" % newphase)
#                isect.append(round(newphase, 5))
#                #sys.stderr.write("hit (%6.4f) ... " % newphase)
#                pass
#            pass
#        results.append(tuple(isect))
#        pass
#    return results
#
#derp = dumb_intersects(tphase, tcurve, orbit_phase, rad_vel)
## %timeit derp = dumb_intersects(tphase, tcurve, orbit_phase, rad_vel)
## 100 loops, best of 3: 8.44 ms per loop

#colors = ['r', 'g', 'b', 'y', 'm', 'c']
#for i, spec in enumerate(derp):
#    use_color = colors[i % len(colors)]
#    phi, vel, mp1, mp2 = spec
#    ax3.axhline(vel, lw=0.5, color=use_color)
#    ax3.axvline(mp1, lw=0.5, color=use_color)
#    ax3.axvline(mp2, lw=0.5, color=use_color)
#    if (i >= 0):
#        break

#def vel_intersect(mod_phi, mod_vel, rv_data, ftol=1e-6):
#    """Look for phase shift between model and data."""
#    results = []
#    prev_rv = mod_vel
#    next_rv = np.roll(prev_rv, -1)
#    vel_sep = np.abs(next_rv - prev_rv)
#    vel_tol = ftol * vel_sep
#    for vel in rv_data: 
#        abs_sum = np.abs(vel - prev_rv) + np.abs(next_rv - vel)
#        btw_idx = np.where((abs_sum - vel_sep) <= vel_tol)[0]
#        isects = []
#        for ix1 in btw_idx:
#            ix2 = (ix1 + 1) % len(mod_phi)
#            rvm_prev, rvm_next = mod_vel[ix1], mod_vel[ix2]
#            phi_prev, phi_next = mod_phi[ix1], mod_phi[ix2]
#            phi_step = (mod_phi[ix2] - mod_phi[ix1]) % 1.0
#            vel_step = (mod_vel[ix2] - mod_vel[ix1])
#            stepfrac = (vel - mod_vel[ix1]) / vel_step
#            newphase = (mod_phi[ix1] + stepfrac * phi_step) % 1.0
#            isects.append(round(newphase, 5))
#            pass
#        results.append(isects)
#    return results
#
##v_isects = vel_intersect(tphase, tcurve, orbit_phase, rad_vel)
#v_isects = vel_intersect(tphase, tcurve, rad_vel)
## %timeit blarg = shape_compare(tphase, tcurve, orbit_phase, rad_vel)
## 1000 loops, best of 3: 490 µs per loop
#
#offsets = (np.array(v_isects) - orbit_phase[:, None]) % 1.0
#off_avg = np.average(offsets, axis=0)
#off_std = np.std(offsets, axis=0)
#bestidx = np.argmin(off_std)
#
#best_offset = off_avg[bestidx]
#best_stddev = off_std[bestidx]


######################################################################
# CHANGELOG (quickplot_rvs.py):
#---------------------------------------------------------------------
#
#  2018-03-26:
#     -- Increased __version__ to 0.1.0.
#     -- Introduced orbit.py for simple fitting.
#
#  2018-03-25:
#     -- Increased __version__ to 0.0.5.
#     -- Basic plots working!
#     -- Increased __version__ to 0.0.1.
#     -- First created quickplot_rvs.py.
#
