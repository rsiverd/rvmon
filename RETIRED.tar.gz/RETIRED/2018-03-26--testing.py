
##--------------------------------------------------------------------------##
## Examine how eclipse phases change with orbital ecc, W:
sys.stderr.write("-----------------------------------------------------\n")
npts_e, npts_w = 100, 100
e_list = np.linspace(0.0, 1.0, npts_e, endpoint=False)
w_list = np.linspace(0.0, 2.0*np.pi, npts_w, endpoint=False)
cphase = np.zeros((2, w_list.size, e_list.size), dtype='float32')


npoints = 10000
orb_phase = np.linspace(0.0, 1.0, npoints, endpoint=False)
mean_anom = 2.0 * np.pi * orb_phase
conj_true_anoms = [0.5*np.pi, 1.5*np.pi]    # anomalies at conjunction
#mean_anom = np.linspace(0.0, 2.0*np.pi, 100, endpoint=False)
for j,ecc in enumerate(e_list, 0):
    sys.stderr.write("Eccentricity %d of %d ...\n" % (j+1, e_list.size))
    true_anom = orbit.calc_true_anom(mean_anom, ecc)
    for i,w in enumerate(w_list, 0):
        LoS_anoms = true_anom + w 
        for k,anom in enumerate(conj_true_anoms):
            ecl_which = (qfo._fastRadianSep(LoS_anoms, anom)).argmin()
            #ecl_Manom = mean_anom[ecl_which]
            #cphase[k, j, i] = orb_phase[ecl_which]
            cphase[k, i, j] = mean_anom[ecl_which]


sys.stderr.write("-----------------------------------------------------\n")


XX, YY = np.meshgrid(e_list, w_list)
U0, V0 = np.cos(cphase[0]), np.sin(cphase[0])
U1, V1 = np.cos(cphase[1]), np.sin(cphase[1])

clf()
plt.quiver(XX, YY, U0, V0, pivot='mid')
xlabel('ecc')
ylabel('omega')

##--------------------------------------------------------------------------##
##--------------------------------------------------------------------------##
## Novel way to identify phase shift?



def shape_compare(phase_model, rv_model, phase_data, rv_data, 
        vtol=0.1, vsep=0.1):
    """Look for phase shift between model and data."""
    shifts = []
    rv_mnext = np.roll(rv_model, -1)
    rv_delta = rv_mnext - rv_model
    for phi,vel in zip(phase_data, rv_data):
        #sys.stderr.write("phi,vel = %f,%f\n" % (phi, vel))
        mod_which = (np.abs(rv_model - vel) < vtol)
        delta_phi = (phase_model[mod_which] - phi) % 1.0
        sys.stderr.write("delta_phi: %s\n" % str(delta_phi))
        shifts.extend(delta_phi.tolist())
    return shifts

tphase, tcurve = qfo.test_orbit(points=1000, norm=True)
pdiff = shape_compare(tphase, tcurve, orbit_phase, rad_vel)





rv_this = tcurve.copy()
rv_next = np.roll(rv_this, -1)
rv_diff = rv_next - rv_this
ph_this = tphase.copy()
ph_next = np.roll(ph_this, -1)

first_rv = rad_vel[0]
one_vel = rad_vel[3]


fractol = 1e-4
vel_tol = fractol * one_vel
abs_sum = np.abs(one_vel - rv_this) + np.abs(one_vel - rv_next)
between = (abs_sum - rv_diff)


sys.stderr.write("one_vel: %10.5f\n" % one_vel)
ax3.axhline(one_vel, c='b', lw=0.5)


def dumb_intersects(mod_phi, mod_vel, phi_data, rv_data):
    results = []
    for i, (phase, rad_vel) in enumerate(zip(phi_data, rv_data)):
        #sys.stderr.write("---------------------------------\n")
        #sys.stderr.write("Data point %d ... " % i)
        isect = [round(phase, 5), round(rad_vel, 5)]
        for ix1 in range(len(mod_phi)):
            ix2 = (ix1 + 1) % len(mod_phi)
            #sys.stderr.write("... ix1,ix2 = %d,%d\n" % (ix1,ix2))
            v1, v2 = mod_vel[ix1], mod_vel[ix2]
            if ((v1 <= one_vel < v2) if (v2 >= v1) else (v1 > one_vel >= v2)):
                phi_step = (mod_phi[ix2] - mod_phi[ix1]) % 1.0
                vel_step = (mod_vel[ix2] - mod_vel[ix1])
                stepfrac = (rad_vel - mod_vel[ix1]) / vel_step
                newphase = (mod_phi[ix1] + stepfrac * phi_step) % 1.0
                #sys.stderr.write("newphase: %10.5f\n" % newphase)
                isect.append(round(newphase, 5))
                #sys.stderr.write("hit (%6.4f) ... " % newphase)
                pass
            pass
        results.append(tuple(isect))
        pass
    return results



def shape_compare(mod_phi, mod_vel, phi_data, rv_data,
        ftol=1e-6):
    """Look for phase shift between model and data."""
    shifts = []
    prev_rv = mod_vel
    next_rv = np.roll(prev_rv, -1)
    vel_sep = np.abs(next_rv - prev_rv)
    vel_tol = ftol * vel_sep
    #rv_delta = next_rv - prev_rv
    for phi,vel in zip(phi_data, rv_data):
        abs_sum = np.abs(vel - prev_rv) + np.abs(next_rv - vel)
        between = np.where((abs_sum - vel_sep) <= vel_tol)[0]
        sys.stderr.write("nbtw: %d\n" % np.sum(between))
        #mod_which = (np.abs(rv_model - vel) < vtol)
        #delta_phi = (phase_model[mod_which] - phi) % 1.0
        #sys.stderr.write("delta_phi: %s\n" % str(delta_phi))
        #shifts.extend(delta_phi.tolist())
    return shifts

blarg = shape_compare(tphase, tcurve, orbit_phase, rad_vel)

    
    
    
    
    #phi, vrad = ph_this[i], rv_this[i]
    #btw = between[i]
    #v1, v2 = rv_this[i], rv_next[i]
    #s1, s2 = sep1[i], sep2[i]
    #vdiff = v2 - v1

    #dumb_btw = (v1 <= one_vel < v2) if (v2 >= v1) else (v1 > one_vel >= v2)
    #sys.stderr.write("RV(%5.3f): %7.3f  |||  " % (phi, vrad))
    #sys.stderr.write("test (%7.3f <= %7.3f < %7.3f) ??? %s "
    #        % (rv_this[i], one_vel, rv_next[i], dumb_btw))
    #if dumb_btw:
    #    sys.stderr.write(" ******** ")
    #    nhits += 1
    #    isect.append(phi)
    #sys.stderr.write("\n")



