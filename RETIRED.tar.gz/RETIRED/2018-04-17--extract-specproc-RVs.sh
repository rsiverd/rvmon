#!/bin/bash
#
# Unpack NRES tarballs and extract BJD/RV for plotting/analysis.
#
# Rob Siverd
# Created:      2018-03-25
# Last updated: 2018-03-28
#--------------------------------------------------------------------------
#**************************************************************************
#--------------------------------------------------------------------------

## Default options:
debug=0 ; clobber=0 ; force=0 ; timer=0 ; vlevel=0
script_version="0.21"
this_prog="${0##*/}"
shopt -s nullglob
# Propagate errors through pipelines: set -o pipefail
# Exit if uninitialized variable used (set -u): set -o nounset
# Exit in case of nonzero status (set -e): set -o errexit

## Program options:
save_file=""
#shuffle=0
#confirmed=0

## Standard scratch files/dirs:
tmp_name="$(date +%Y%m%d.%H%M%S).$$.$(whoami)"
tmp_root="/tmp"
[ -d /dev/shm ] && [ -w /dev/shm ] && tmp_root="/dev/shm"
#tmp_dir="$tmp_root"
tmp_dir="$tmp_root/$tmp_name"
mkdir -p $tmp_dir
foo="$tmp_dir/foo_$$.txt"
bar="$tmp_dir/bar_$$.txt"
baz="$tmp_dir/baz_$$.fits"
qux="$tmp_dir/qux_$$.fits"
jnk="$foo $bar $baz $qux"  # working copy
def_jnk="$jnk"             # original set
dir_cleanup='(echo -e "\nAutomatic clean up ... " ; cmde "rm -vrf $tmp_dir")'
jnk_cleanup='for X in $jnk ; do [ -f $X ] && cmde "rm -vf $X" ; done'
trap "$jnk_cleanup" EXIT
##trap '[ -d $tmp_dir ] && cmde "rm -vrf $tmp_dir"' EXIT
#trap "[ -d $tmp_dir ] && $dir_cleanup" EXIT
#trap "[ -d $tmp_dir ] && $dir_cleanup ; $jnk_cleanup" EXIT
#trap 'oops=$? ; echo ; exit $oops' HUP INT TERM

## Required programs:
declare -a need_exec
need_exec+=( awk cat compactify FuncDef getopt )
need_exec+=( imhget jdcalc pdftotext sed tar tr )
#need_exec+=( shuf shuffle sort ) # for randomization
for need in ${need_exec[*]}; do
   if ! ( /usr/bin/which $need >& /dev/null ); then
      echo "Error:  can't find '$need' in PATH !!" >&2
      exit 1
   fi
done

## Helper function definitions:
fd_args="--argchk --colors --cmde --echo"
#fd_args+=" --Critical"
fd_args+=" --rowwrite"
#fd_args+=" --timers"
fd_args+=" --warnings"
FuncDef $fd_args >/dev/null || exit $?
eval "$(FuncDef $fd_args)"  || exit $?

##--------------------------------------------------------------------------##
## Syntax / help menu:
usage () {
   cat << EOH

Usage: $this_prog [options] tarball_list.txt 
Pull JD, RV out of NRES tarballs.
Version: $script_version

Program options:
    -c, --clobber       allow overwrite of output file
    -o, --output=FILE   send output to FILE
    -r, --random        randomize processing order (for parallel operation)

Other options:
        --deps          return list of required programs (for parent script)
    -h, --help          display this page
    -q, --quiet         less on-screen info and progress reporting
    -t, --timer         measure and report script execution time
    -v, --verbose       more on-screen info and progress reporting

EOH
#        --debug         extra verbosity to assist bug hunting
#    -f, --force         force redo of whatever this script does
#    -f, --force         allow clobbering of output file
}

##--------------------------------------------------------------------------##
## Parse command line with getopt (reorders and stores CL args):
s_opts="co:rhqtv" # f
l_opts="START,clobber,output:,random"
l_opts+=",debug,deps,help,quiet,timer,verbose" # force
args=`getopt -n $this_prog -o $s_opts -l $l_opts -- "$@"` ; failed=$?

## Check for parsing errors:
if [ $failed -ne 0 ]; then 
   echo "Try \`$this_prog --help' for more information." >&2
   exit 1
fi

## Change the arguments in the environment (e.g., $1, $2, ... $N):
eval set -- "$args"

## Loop through arguments (shift removes them from environment):
while true ; do
   case $1 in
      #-------------------------------------------------------------------
     #--START)
     #   confirmed=1
     #   shift
     #   ;;
      #-------------------------------------------------------------------
      -c|--clobber)
         [ $vlevel -ge 0 ] && yecho "Enabled output clobber!\n" >&2
         clobber=1
         shift
         ;;
      #-------------------------------------------------------------------
     #-n|--number)
     #   case $2 in
     #      -*)
     #         msg="Option -n|--number requires an argument!"
     #         #msg="Option -n|--number needs a positive integer argument!"
     #         #msg="Option -n|--number needs a positive numerical argument!"
     #         Recho "\n${msg}\n" >&2
     #         usage >&2
     #         exit 1
     #         ;;
     #      *)
     ###       if !( num_check_pass $2 ); then
     ###       if !( num_check_pass $2 ) || (is_negative $2); then
     ###       if !( int_check_pass $2 ) || [ $2 -lt 0 ]; then
     #            Recho "Invalid value: " >&2 ; Yecho "$2 \n\n" >&2
     #            exit 1
     #         fi
     #         num_val=$2
     #         ;;
     #   esac
     #   [ $vlevel -ge 0 ] && yecho "Using value: ${num_val}\n" >&2
     #   shift 2
     #   ;;
      -o|--output)
         case $2 in
            -*)
               Recho "\nOption -o|--output requires an argument!\n" >&2
               usage >&2
               exit 1
               ;;
            *)
               save_file=$2
               # check value here ...
               if [ $clobber -eq 0 ] && [ -f $save_file ]; then
                  Recho "\nFile already exists: " >&2
                  Yecho "$save_file \n\n" >&2
                  exit 1
               fi
               ;;
         esac
         [ $vlevel -ge 0 ] && yecho "Output to: $save_file \n" >&2
         shift 2
         ;;
      -r|--random)
         [ $vlevel -ge 0 ] && yecho "Randomizing order!\n" >&2
         shuffle=1
         shift
         ;;
      #-------------------------------------------------------------------
      # Additional options (output control etc.):
      --debug)
         yecho "Debugging mode enabled!\n"
         debug=1
         shift
         ;;
      --deps)
         echo ${need_exec[*]}
         exit 0
         ;;
     #-f|--force)
     #   [ $vlevel -ge 0 ] && yecho "Output clobbering enabled!\n" >&2
     #   [ $vlevel -ge 0 ] && yecho "Forcing <WHAT THIS SCRIPT DOES>!\n" >&2
     #   clobber=1
     #   force=1
     #   shift
     #   ;;
      -h|--help)
         usage
         exit 0
         ;;
      -q|--quiet)
         (( vlevel-- ))
         shift
         ;;
      -t|--timer)
         [ $vlevel -ge 1 ] && yecho "Timing script execution!\n" >&2
         timer=1
         shift
         ;;
      -v|--verbose)
         (( vlevel++ ))
         shift
         ;;
      #-------------------------------------------------------------------
      --)
         shift
         break 
         ;;
      *)
         echo -e "\n$this_prog error: unhandled option: $1 \n" >&2
         exit 1 
         ;;
      #-------------------------------------------------------------------
   esac
done

## Check for an appropriate number of arguments:
#if [ $confirmed -ne 1 ]; then
if [ -z "$1" ]; then
   usage >&2
   exit 1
fi
obs_list="$1"
[ -f $obs_list ] || PauseAbort "Can't find file: $obs_list"

[ $debug -eq 1 ] && vlevel=3
[ $vlevel -gt 1 ] && echo "Verbosity: $vlevel" >&2

##**************************************************************************##
##==========================================================================##
##--------------------------------------------------------------------------##

tgz_list=( `awk '{ print $1 }' $obs_list` )
ntarball=${#tgz_list[*]}
if [ $ntarball -eq 0 ]; then
   recho "No files listed!\n"
   exit 0
fi
#echo "tgz_list: ${tgz_list[*]}"

##--------------------------------------------------------------------------##
## Data extraction from PDF plots:
mine_pdf_plots () {
   local content="$tmp_dir/content.txt"
   pdftotext $1 $content
   rv_val=$(grep -m1 '^RV ='     $content | awk '{ print $3 }')
   bc_val=$(grep -m1 '^BC ='     $content | awk '{ print $3 }')
   cc_val=$(grep -m1 '^CCshft =' $content | awk '{ print $3 }')

   # deal with dangerous placeholders:
   rv_fix=$(tr -d \* <<< "$rv_val"); [ -z "$rv_fix" ] && rv_val="nan"
   bc_fix=$(tr -d \* <<< "$bc_val"); [ -z "$bc_fix" ] && bc_val="nan"
   cc_fix=$(tr -d \* <<< "$cc_val"); [ -z "$cc_fix" ] && cc_val="nan"

   target=$(head -1 $content | cut -d, -f1)
   snrval=$(head -1 $content | cut -d, -f7 | tr -d ' ' | cut -d= -f2)

   nwords=`echo "$rv_val $bc_val $cc_val $snrval $target" | awk '{print NF}'`
   strdata="${rv_val},${bc_val},${cc_val},${snrval},${target}"
   if [ $nwords -gt 10 ]; then
      echo "summary: '$1'" >&2
      echo "rv_val: '$rv_val'" >&2
      echo "bc_val: '$bc_val'" >&2
      echo "cc_val: '$cc_val'" >&2
      echo "target: '$target'" >&2
      echo "snrval: '$snrval'" >&2
      return 1
   fi
   echo "$strdata"
   rm $content 2>/dev/null
   return 0
}

##--------------------------------------------------------------------------##
## Column config:
cols="tarball obsdate exptime jdstart bjd_obs rvval bcval ccval snr target"
ncols=$(echo $cols | awk '{ print NF }')
echo "Expected output columns: $ncols"

## Extract everything:
ntodo=0
count=0
echo "$cols" | sed 's/ /,/g' > $foo
for tball in ${tgz_list[*]}; do
   yecho "\rExtracting measurement $((++count)) of $ntarball ... " >&2
   tbase="${tball##*/}"
   tarch="${tbase%.gz}"
   troot="${tarch%.tar}"
   extr_dir="$tmp_dir/$troot"
   if !( vcmde "tar -C $tmp_dir -zxf $tball" >&2 ); then
      recho "Archive extraction failed!! Skipping file ...\n" >&2
      continue
   fi

   # Identify PDF and RV table for data extraction:
   pdf_file="${extr_dir}/${troot}.pdf"
   rv_table="${extr_dir}/${troot}-rv.fits.fz"
   for item in $pdf_file $rv_table; do
      if [ ! -f $item ]; then
         recho "File not found: $item \n" >&2
         continue
      fi
   done

   # Retrieve data, save to file:
   obsdata=( `imhget DATE-OBS EXPTIME BJD0 $rv_table` )
   jdstart=$(jdcalc -D ${obsdata[0]})
   #results=( `mine_pdf_plots $pdf_file` ); errors=$?
   bigresult=$(mine_pdf_plots $pdf_file); errors=$?
   obs_string=$(echo ${obsdata[*]} | sed 's/ /,/g')
   #nresults="${#results[@]}"
   #echo "obs_string: $obs_string"
   #exit
   #echo "nresults=$nresults, ndata: $ndata"
   if [ $errors -eq 0 ]; then
      #echo "$tbase ${obsdata[*]} $jdstart ${results[*]}"
      #echo "$tbase ${obsdata[*]} $jdstart ${results[*]}" | tee -a $foo
      #data_string="$tbase ${obsdata[*]} $jdstart ${results[*]}"
      data_string="${tbase},${obs_string},${jdstart},${bigresult}"
      #ndata=$(echo $data_string | awk '{ print NF }')
      #echo "$tbase ${obsdata[*]} $jdstart ${results[*]}" >> $foo
      echo "$data_string" >> $foo
   else
      Recho "DETECTED ERROR with PDF:\n" >&2
      yecho "--> '$pdf_file'\n\n" >&2
      #exit 1
   fi
   vcmde "rm -rf $extr_dir" >&2 # clean up
   [ $ntodo -gt 0 ] && [ $count -ge $ntodo ] && break
done
gecho "done.\n" >&2

##--------------------------------------------------------------------------##
## Clean up and save output:
#if ! ( vcmde "compactify $foo > $bar" ); then
#   recho "Compactification error ... file content:\n" >&2
#   #cmde "less $foo"
#fi
mv -f $foo $bar
if [ -n "$save_file" ]; then
   cmde "mv -f $bar $save_file"  || exit $?
else
   cat $bar
fi

##--------------------------------------------------------------------------##
## Clean up:
[ -d $tmp_dir ] && [ -O $tmp_dir ] && rm -rf $tmp_dir
[ -f $foo ] && rm -f $foo
[ -f $bar ] && rm -f $bar
[ -f $baz ] && rm -f $baz
[ -f $qux ] && rm -f $qux
exit 0

######################################################################
# CHANGELOG (extract-specproc-RVs.sh):
#---------------------------------------------------------------------
#
#  2018-03-28:
#     -- Increased script_version to 0.21.
#     -- Now replace ******** placeholders with nan to simplify analysis.
#
#  2018-03-27:
#     -- Increased script_version to 0.20.
#     -- Output data now in CSV format to handle whitespace in object names.
#     -- Added checks for bogus data from PDF files.
#     -- Fixed some error handling.
#
#  2018-03-25:
#     -- Increased script_version to 0.10.
#     -- Renamed script to extract-specproc-RVs.sh.
#     -- Script now working as intended.
#     -- Increased script_version to 0.01.
#     -- First created specproc-rv-extraction.sh.
#
