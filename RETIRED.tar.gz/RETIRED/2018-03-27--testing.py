
##--------------------------------------------------------------------------##
## Examine how eclipse phases change with orbital ecc, W:
sys.stderr.write("-----------------------------------------------------\n")
npts_e, npts_w = 100, 100
e_list = np.linspace(0.0, 1.0, npts_e, endpoint=False)
w_list = np.linspace(0.0, 2.0*np.pi, npts_w, endpoint=False)
cphase = np.zeros((2, w_list.size, e_list.size), dtype='float32')


npoints = 10000
orb_phase = np.linspace(0.0, 1.0, npoints, endpoint=False)
mean_anom = 2.0 * np.pi * orb_phase
conj_true_anoms = [0.5*np.pi, 1.5*np.pi]    # anomalies at conjunction
#mean_anom = np.linspace(0.0, 2.0*np.pi, 100, endpoint=False)
for j,ecc in enumerate(e_list, 0):
    sys.stderr.write("Eccentricity %d of %d ...\n" % (j+1, e_list.size))
    true_anom = orbit.calc_true_anom(mean_anom, ecc)
    for i,w in enumerate(w_list, 0):
        LoS_anoms = true_anom + w 
        for k,anom in enumerate(conj_true_anoms):
            ecl_which = (qfo._fastRadianSep(LoS_anoms, anom)).argmin()
            #ecl_Manom = mean_anom[ecl_which]
            #cphase[k, j, i] = orb_phase[ecl_which]
            cphase[k, i, j] = mean_anom[ecl_which]


sys.stderr.write("-----------------------------------------------------\n")


XX, YY = np.meshgrid(e_list, w_list)
U0, V0 = np.cos(cphase[0]), np.sin(cphase[0])
U1, V1 = np.cos(cphase[1]), np.sin(cphase[1])

clf()
plt.quiver(XX, YY, U0, V0, pivot='mid')
xlabel('ecc')
ylabel('omega')

##--------------------------------------------------------------------------##
##--------------------------------------------------------------------------##
## Novel way to identify phase shift?

def find_intersects(test_pts, data, ftol=1e-6, cyclic=True):
    """Find positions where 'data' array crosses values in test_pts."""
    results = []
    keepidx = slice(None, None, 1) if cyclic else slice(None, -1, 1)
    nextval = np.roll(data, -1)
    absdiff = np.abs(nextval - data)

    # find intersections:
    for x in test_pts:
        abs_sum = np.abs(nextval - x) + np.abs(x - data)
        ismatch = np.isclose(abs_sum, absdiff, rtol=ftol)[keepidx]
        results.append(ismatch.nonzero()[0].tolist())
    return results

def intersection_phases(rv_data, model_phase, model_radvel, ftol=1e-6):
    # Get lower indexes of intersection points:
    isect_idx = find_intersects(rv_data, model_radvel, ftol=ftol, cyclic=True)
    #isect_idx = np.array(isect_idx)

    # Interpolate phases of intersection:
    #for ix1 in isect_idx.flatten():
    for trv, ix1 in zip(rv_data, isect_idx):
            ix2 = (ix1 + 1) % len(model_phase)
            vel_step = (model_radvel[ix2] - model_radvel[ix1])
            stepfrac = (trv - model_radvel[ix1]) / vel_step
            phi_step = (model_phase[ix2] - model_phase[ix1]) % 1.0
            newphase = (model_phase[ix1] + stepfrac * phi_step) % 1.0
            isects.append(round(newphase, 5))
            pass
        results.append(isects)

        #sys.stderr.write("idx: %s\n" % str(idx))
    return isect_idx

asdf = intersection_phases(rad_vel, tphase, tcurve)

def test_orbit_shape(rv_phi, rv_vel, model_phi, model_vel, ftol=1e-6):
    """
    Compare orbit model to RV data points. Calculate phase offset
    and estimate quality of shape match.
    """

def vel_intersect(rv_data, mod_phi, mod_vel, ftol=1e-6):
    """Look for phase shift using intersection of model and data."""
    results = []
    prev_rv = mod_vel
    next_rv = np.roll(prev_rv, -1)
    vel_sep = np.abs(next_rv - prev_rv)
    vel_tol = ftol * vel_sep
    for vel in rv_data:   
        abs_sum = np.abs(vel - prev_rv) + np.abs(next_rv - vel)
        btw_idx = np.where((abs_sum - vel_sep) <= vel_tol)[0]
        isects = []
        for ix1 in btw_idx:
            ix2 = (ix1 + 1) % len(mod_phi)
            #rvm_prev, rvm_next = mod_vel[ix1], mod_vel[ix2]
            #phi_prev, phi_next = mod_phi[ix1], mod_phi[ix2]
            phi_step = (mod_phi[ix2] - mod_phi[ix1]) % 1.0
            vel_step = (mod_vel[ix2] - mod_vel[ix1])
            stepfrac = (vel - mod_vel[ix1]) / vel_step
            newphase = (mod_phi[ix1] + stepfrac * phi_step) % 1.0
            isects.append(round(newphase, 5))
            pass
        results.append(isects)
    return results

v_isects = vel_intersect(rad_vel, tphase, tcurve)
# %timeit blarg = shape_compare(tphase, tcurve, orbit_phase, rad_vel)
# 1000 loops, best of 3: 490 µs per loop

offsets = (np.array(v_isects) - orbit_phase[:, None]) % 1.0
off_avg = np.average(offsets, axis=0)
off_std = np.std(offsets, axis=0)
bestidx = np.argmin(off_std)

best_offset = off_avg[bestidx]
best_stddev = off_std[bestidx]

##--------------------------------------------------------------------------##
## Examine how eclipse phases change with orbital ecc, W:
sys.stderr.write("-----------------------------------------------------\n")
npts_e, npts_w = 20, 20
e_list = np.linspace(0.0, 1.0, npts_e, endpoint=False)
w_list = np.linspace(0.0, 2.0*np.pi, npts_w, endpoint=False)
cphase = np.zeros((2, w_list.size, e_list.size), dtype='float32')


npoints = 10000
orb_phase = np.linspace(0.0, 1.0, npoints, endpoint=False)
mean_anom = 2.0 * np.pi * orb_phase
conj_true_anoms = [0.5*np.pi, 1.5*np.pi]    # anomalies at conjunction
#mean_anom = np.linspace(0.0, 2.0*np.pi, 100, endpoint=False)
for j,ecc in enumerate(e_list, 0):
    sys.stderr.write("Eccentricity %d of %d ...\n" % (j+1, e_list.size))
    true_anom = orbit.calc_true_anom(mean_anom, ecc)
    for i,w in enumerate(w_list, 0):
        LoS_anoms = true_anom + w 

